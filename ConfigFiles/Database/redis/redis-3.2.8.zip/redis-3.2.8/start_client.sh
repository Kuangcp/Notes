basepath=$(cd `dirname $0`; pwd)
$basepath/redis-cli -p 6379
