## 绿色安装redis
- 只要下载源码包，解压
- 在解压根目录 `make`
- 打开src目录 复制以下文件
    - `redis-server`
    - `redis-cli`
    - `redis-benchmark`
    - 解压根目录的 `redis.conf`
- 随意新建一个目录，将四个文件拷过来，就可以直接运行了
- `./redis-server redis.conf`

